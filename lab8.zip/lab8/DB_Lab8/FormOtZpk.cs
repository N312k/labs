﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab8
{
    public partial class FormOtZpk : Form
    {
        private Form prevForm;
        private string viewName;
        public FormOtZpk(Form prevForm, string viewName)
        {
            InitializeComponent();
            this.prevForm = prevForm;
            this.viewName = viewName;
        }

        private void FormOtZpk_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsView(viewName))
                {
                    MessageBox.Show($"'{viewName}' не является представлением!");
                    return;
                }

                List<List<string>> data = PostgreSQL.SelectAll($"\"{viewName}\"");
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();

                foreach (string column in data[0])
                {
                    dataGridView1.Columns.Add(column, column);
                }

                bool skip = false;
                foreach (List<string> list in data)
                {
                    if (skip)
                    {
                        string[] row = new string[list.Count];
                        int k = 0;
                        foreach (string column in list)
                        {
                            row[k] = column;
                            k++;
                        }
                        dataGridView1.Rows.Add(row);
                    }
                    skip = true;
                }

                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoResizeRows();
                dataGridView1.Width = dataGridView1.RowHeadersWidth
                    + dataGridView1.Columns.GetColumnsWidth(DataGridViewElementStates.Visible) + 24;
                dataGridView1.Height = Math.Min(dataGridView1.ColumnHeadersHeight
                    + dataGridView1.Rows.GetRowsHeight(DataGridViewElementStates.Visible) + 32, 400);
                dataGridView1.Refresh();
                if (dataGridView1.Left + dataGridView1.Width + 32 > Width)
                    Width += dataGridView1.Left + dataGridView1.Width + 32 - Width;
                if (dataGridView1.Top + dataGridView1.Height + 64 > Height)
                    Height += dataGridView1.Top + dataGridView1.Height + 64 - Height;
            }
            catch (Exception ex) { MessageBox.Show("Error!\n" + ex.Message); }
        }
        private bool IsView(string viewName)
        {
            try
            {
                if (PostgreSQL.GetConnection() == null || PostgreSQL.GetConnection().State != ConnectionState.Open)
                {
                    MessageBox.Show("Нет подключения к базе данных.");
                    return false;
                }

                string query = "SELECT table_name FROM information_schema.views WHERE table_schema = 'public' AND table_name = @viewName";
                using (NpgsqlCommand cmd = new NpgsqlCommand(query, PostgreSQL.GetConnection()))
                {
                    cmd.Parameters.AddWithValue("@viewName", viewName);
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        return reader.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при проверке представления: " + ex.Message);
                return false;
            }
        }
        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
