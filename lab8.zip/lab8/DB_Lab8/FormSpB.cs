﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab8
{
    public partial class FormSpB : Form
    {
        private Form prevForm;
        private string tableName;
        public FormSpB(Form prevForm, string tableName)
        {
            InitializeComponent();
            this.prevForm = prevForm;
            this.tableName = tableName;
        }
        private bool IsReferenceTable(string tableName)
        {
            string[] referenceTables = { "Тип ремонта", "Диспетчер", "Спонсор", "Рабочие", "Бригада", "Мастер", "Организация" };

            return referenceTables.Contains(tableName);
        }
        private void FormSpB_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsReferenceTable(tableName))
                {
                    MessageBox.Show($"'{tableName}' не является справочной таблицей!");
                    return;
                }

                List<List<string>> data = PostgreSQL.SelectAll($"\"{tableName}\"");
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();

                foreach (string column in data[0])
                {
                    dataGridView1.Columns.Add(column, column);
                }

                bool skip = false;
                foreach (List<string> list in data)
                {
                    if (skip)
                    {
                        string[] row = new string[list.Count];
                        int k = 0;
                        foreach (string column in list)
                        {
                            row[k] = column;
                            k++;
                        }
                        dataGridView1.Rows.Add(row);
                    }
                    skip = true;
                }

                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoResizeRows();
                dataGridView1.Width = dataGridView1.RowHeadersWidth
                    + dataGridView1.Columns.GetColumnsWidth(DataGridViewElementStates.Visible) + 24;
                dataGridView1.Height = Math.Min(dataGridView1.ColumnHeadersHeight
                    + dataGridView1.Rows.GetRowsHeight(DataGridViewElementStates.Visible) + 32, 400);
                dataGridView1.Refresh();
                if (dataGridView1.Left + dataGridView1.Width + 32 > Width)
                    Width += dataGridView1.Left + dataGridView1.Width + 32 - Width;
                if (dataGridView1.Top + dataGridView1.Height + 64 > Height)
                    Height += dataGridView1.Top + dataGridView1.Height + 64 - Height;
            }
            catch (Exception ex) { MessageBox.Show("Error!\n" + ex.Message); }
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
