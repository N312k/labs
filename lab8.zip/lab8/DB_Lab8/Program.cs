﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.Data.Common;

namespace lab8
{
    public class PostgreSQL
    {
        private static NpgsqlConnection con = null;

        public static NpgsqlConnection GetConnection()
        {
            return con;
        }

        public static void OpenConnection(string host, string port, string user, string pass, string db)
        {
            if (con != null)
            {
                if (con.State == ConnectionState.Open) con.Close();
                con.Dispose();
            }
            con = new NpgsqlConnection(@"Server=" + host + ";Port=" + port + ";User Id=" + user + ";Password=" + pass + ";Database=" + db + ";");
            con.Open();
            if (con.State == ConnectionState.Open) MessageBox.Show("Connected!");
            else MessageBox.Show("NOT Connected!");
        }

        public static List<List<string>> SelectAll(string table_view)
        {
            List<List<string>> list = new List<List<string>>();
            if (con != null)
            {
                if (con.State == ConnectionState.Open)
                {
                    NpgsqlCommand com = con.CreateCommand();
                    com.CommandText = "Select * from public." + table_view;
                    NpgsqlDataReader dt = com.ExecuteReader(CommandBehavior.Default);
                    bool add_names = false;
                    while (dt.Read())
                    {
                        try
                        {
                            if (!add_names)
                            {
                                List<string> list_names = new List<string>();
                                for (int i = 0; i < dt.FieldCount; i++)
                                {
                                    list_names.Add(dt.GetName(i));
                                }
                                list.Add(list_names);
                                add_names = true;
                            }
                            List<string> inside_list = new List<string>();
                            for (int i = 0; i < dt.FieldCount; i++)
                            {
                                inside_list.Add(dt.GetValue(i).ToString());
                            }
                            list.Add(inside_list);
                        }
                        catch (Exception ex) { MessageBox.Show(ex.Message); }
                    }
                    dt.Close();
                }
                else throw new Exception("Not Opened Connection!");
            }
            else throw new Exception("Not Connected!");
            return list;
        }
    }

    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}