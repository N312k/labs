﻿using System.Drawing;
using System.Windows.Forms;
using System;

namespace lab8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.типРемонтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.диспетчерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.спонсорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рабочиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.бригадаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мастерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.организацияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.заявкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заказчикToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.заявкиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.типыРемонтовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(5, 37);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(113, 22);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(5, 68);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(113, 22);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(183, 38);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(113, 22);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(183, 65);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(113, 22);
            this.textBox4.TabIndex = 3;
            this.textBox4.TabStop = false;
            this.textBox4.UseSystemPasswordChar = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(95, 98);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(113, 22);
            this.textBox5.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(95, 128);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 25);
            this.button1.TabIndex = 5;
            this.button1.Text = "connect";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(127, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "host";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(127, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "port";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(304, 38);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "user";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(304, 68);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "pass";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(216, 104);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "DB";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(495, 28);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "Данные";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.типРемонтаToolStripMenuItem,
            this.диспетчерToolStripMenuItem,
            this.спонсорToolStripMenuItem,
            this.рабочиеToolStripMenuItem,
            this.бригадаToolStripMenuItem,
            this.мастерToolStripMenuItem,
            this.организацияToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(117, 24);
            this.toolStripMenuItem1.Text = "Справочники";
            // 
            // типРемонтаToolStripMenuItem
            // 
            this.типРемонтаToolStripMenuItem.Name = "типРемонтаToolStripMenuItem";
            this.типРемонтаToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.типРемонтаToolStripMenuItem.Text = "Тип ремонта";
            this.типРемонтаToolStripMenuItem.Click += new System.EventHandler(this.типРемонтаToolStripMenuItem_Click);
            // 
            // диспетчерToolStripMenuItem
            // 
            this.диспетчерToolStripMenuItem.Name = "диспетчерToolStripMenuItem";
            this.диспетчерToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.диспетчерToolStripMenuItem.Text = "Диспетчер";
            this.диспетчерToolStripMenuItem.Click += new System.EventHandler(this.диспетчерToolStripMenuItem_Click);
            // 
            // спонсорToolStripMenuItem
            // 
            this.спонсорToolStripMenuItem.Name = "спонсорToolStripMenuItem";
            this.спонсорToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.спонсорToolStripMenuItem.Text = "Спонсор";
            this.спонсорToolStripMenuItem.Click += new System.EventHandler(this.спонсорToolStripMenuItem_Click);
            // 
            // рабочиеToolStripMenuItem
            // 
            this.рабочиеToolStripMenuItem.Name = "рабочиеToolStripMenuItem";
            this.рабочиеToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.рабочиеToolStripMenuItem.Text = "Рабочие";
            this.рабочиеToolStripMenuItem.Click += new System.EventHandler(this.рабочиеToolStripMenuItem_Click);
            // 
            // бригадаToolStripMenuItem
            // 
            this.бригадаToolStripMenuItem.Name = "бригадаToolStripMenuItem";
            this.бригадаToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.бригадаToolStripMenuItem.Text = "Бригада";
            this.бригадаToolStripMenuItem.Click += new System.EventHandler(this.бригадаToolStripMenuItem_Click);
            // 
            // мастерToolStripMenuItem
            // 
            this.мастерToolStripMenuItem.Name = "мастерToolStripMenuItem";
            this.мастерToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.мастерToolStripMenuItem.Text = "Мастер";
            this.мастерToolStripMenuItem.Click += new System.EventHandler(this.мастерToolStripMenuItem_Click);
            // 
            // организацияToolStripMenuItem
            // 
            this.организацияToolStripMenuItem.Name = "организацияToolStripMenuItem";
            this.организацияToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.организацияToolStripMenuItem.Text = "Организация";
            this.организацияToolStripMenuItem.Click += new System.EventHandler(this.организацияToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.заявкиToolStripMenuItem,
            this.заказчикToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(78, 24);
            this.toolStripMenuItem2.Text = "Данные";
            // 
            // заявкиToolStripMenuItem
            // 
            this.заявкиToolStripMenuItem.Name = "заявкиToolStripMenuItem";
            this.заявкиToolStripMenuItem.Size = new System.Drawing.Size(154, 26);
            this.заявкиToolStripMenuItem.Text = "Заявки";
            this.заявкиToolStripMenuItem.Click += new System.EventHandler(this.заявкиToolStripMenuItem_Click);
            // 
            // заказчикToolStripMenuItem
            // 
            this.заказчикToolStripMenuItem.Name = "заказчикToolStripMenuItem";
            this.заказчикToolStripMenuItem.Size = new System.Drawing.Size(154, 26);
            this.заказчикToolStripMenuItem.Text = "Заказчик";
            this.заказчикToolStripMenuItem.Click += new System.EventHandler(this.заказчикToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.заявкиToolStripMenuItem1,
            this.типыРемонтовToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(73, 24);
            this.toolStripMenuItem3.Text = "Отчеты";
            // 
            // заявкиToolStripMenuItem1
            // 
            this.заявкиToolStripMenuItem1.Name = "заявкиToolStripMenuItem1";
            this.заявкиToolStripMenuItem1.Size = new System.Drawing.Size(242, 26);
            this.заявкиToolStripMenuItem1.Text = "Заявки по критериям";
            this.заявкиToolStripMenuItem1.Click += new System.EventHandler(this.заявкиToolStripMenuItem1_Click);
            // 
            // типыРемонтовToolStripMenuItem
            // 
            this.типыРемонтовToolStripMenuItem.Name = "типыРемонтовToolStripMenuItem";
            this.типыРемонтовToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.типыРемонтовToolStripMenuItem.Text = "Типы ремонтов";
            this.типыРемонтовToolStripMenuItem.Click += new System.EventHandler(this.типыРемонтовToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(118, 24);
            this.toolStripMenuItem4.Text = "О программе";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(67, 24);
            this.toolStripMenuItem5.Text = "Выход";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 169);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "PostreSQL Connect";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem toolStripMenuItem5;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem типРемонтаToolStripMenuItem;
        private ToolStripMenuItem диспетчерToolStripMenuItem;
        private ToolStripMenuItem спонсорToolStripMenuItem;
        private ToolStripMenuItem рабочиеToolStripMenuItem;
        private ToolStripMenuItem бригадаToolStripMenuItem;
        private ToolStripMenuItem мастерToolStripMenuItem;
        private ToolStripMenuItem организацияToolStripMenuItem;
        private ToolStripMenuItem заявкиToolStripMenuItem;
        private ToolStripMenuItem заказчикToolStripMenuItem;
        private ToolStripMenuItem заявкиToolStripMenuItem1;
        private ToolStripMenuItem типыРемонтовToolStripMenuItem;
    }
}
