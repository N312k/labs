﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql;
using System.Data.Common;
using lab8;
using DB_Lab8;

namespace lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PostgreSQL.OpenConnection("localhost", "5432", "postgres", "postpass", "lab5");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                PostgreSQL.OpenConnection(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text);
            }
            catch (Exception ex) { MessageBox.Show("Error!\n" + ex.Message); }
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            FormAbout about = new FormAbout(this);
            about.Show();
            this.Hide();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

      

        private void типРемонтаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSpravTP reference = new FormSpravTP(this, "Тип ремонта");
            reference.Show();
            this.Hide();
        }

        private void диспетчерToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSpD reference = new FormSpD(this, "Диспетчер");
            reference.Show();
            this.Hide();
        }

        private void спонсорToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSpS reference = new FormSpS(this, "Спонсор");
            reference.Show();
            this.Hide();
        }

        private void рабочиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSpR reference = new FormSpR(this, "Рабочие");
            reference.Show();
            this.Hide();
        }

        private void бригадаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSpB reference = new FormSpB(this, "Бригада");
            reference.Show();
            this.Hide();
        }

        private void мастерToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSpM reference = new FormSpM(this, "Мастер");
            reference.Show();
            this.Hide();
        }

        private void организацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSpO reference = new FormSpO(this, "Организация");
            reference.Show();
            this.Hide();
        }

        private void заявкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOpZa reference = new FormOpZa(this, "Заявки на ремонт");
            reference.Show();
            this.Hide();
        }

        private void заказчикToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOpZ reference = new FormOpZ(this, "Заказчик");
            reference.Show();
            this.Hide();
        }

    
        private void заявкиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormOtZpk ot1 = new FormOtZpk(this, "Заявки_по_критериям");
            ot1.Show();
            this.Hide();
        }

        private void типыРемонтовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOtTP ot2 = new FormOtTP(this, "Заявки_по_критериям");
            ot2.Show();
            this.Hide();
        }
    }
}
